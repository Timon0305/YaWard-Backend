const mongoose = require('mongoose');

const AdminSchema = new mongoose.Schema({
    username: {
        type: String
    },
    email: {
        type: String
    },
    password: {
        type: String
    },
    role: {
        type: String,
        default: 'admin'
    },
    status: {
        type: String,
        default: "pending"
    },
    created_at: {
        type: Date,
        default: Date.now
    },
    updated_at: {
        type: Date,
        default: Date.now
    },
    deleted_at: {
        type: Date,
        default: null
    }
});

const Admin = mongoose.model('Admin', AdminSchema);

module.exports = Admin;