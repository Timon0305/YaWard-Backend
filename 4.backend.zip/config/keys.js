module.exports = {
    MongoURI: 'mongodb://localhost:27017/yalla'
};